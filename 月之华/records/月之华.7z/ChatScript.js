// DOM元素
const themeToggle = document.getElementById('themeToggle');
const saveConfigBtn = document.getElementById('saveConfig');
const testConnectionBtn = document.getElementById('testConnection');
const sendButton = document.getElementById('sendButton');
const userInput = document.getElementById('userInput');
const chatHistory = document.getElementById('chatHistory');
const includeHistory = document.getElementById('includeHistory');
const apiEndpoint = document.getElementById('apiEndpoint');
const aiModel = document.getElementById('aiModel');
const systemPrompt = document.getElementById('systemPrompt');
const displayedSystemPrompt = document.getElementById('displayedSystemPrompt');
const clearSystemPromptBtn = document.getElementById('clearSystemPrompt');
const temperature = document.getElementById('temperature');
const maxTokens = document.getElementById('maxTokens');
const connectionStatusText = document.getElementById('connectionStatusText');
const statusIndicator = document.querySelector('.status-indicator');
const apiStatus = document.getElementById('apiStatus');
const currentModel = document.getElementById('currentModel');
const ttsText = document.getElementById('ttsText');
const ttsButton = document.getElementById('ttsButton');
const stopTTSBtn = document.getElementById('stopTTS');
const ttsSpeed = document.getElementById('ttsSpeed');
const ttsSpeedValue = document.getElementById('ttsSpeedValue');
const ttsVolume = document.getElementById('ttsVolume');
const ttsVolumeValue = document.getElementById('ttsVolumeValue');
const importConfigBtn = document.getElementById('importConfig');
const saveModal = document.getElementById('saveModal');
const importModal = document.getElementById('importModal');
const configJson = document.getElementById('configJson');
const configName = document.getElementById('configName');
const confirmSaveBtn = document.getElementById('confirmSaveBtn');
const cancelSaveBtn = document.getElementById('cancelSaveBtn');
const importConfigJson = document.getElementById('importConfigJson');
const confirmImportBtn = document.getElementById('confirmImportBtn');
const cancelImportBtn = document.getElementById('cancelImportBtn');
const configList = document.getElementById('configList');
const deleteAllConfigsBtn = document.getElementById('deleteAllConfigs');
const ttsApiEndpoint = document.getElementById('ttsApiEndpoint');
const ttsModeCustom = document.getElementById('ttsModeCustom');
const ttsModeSystem = document.getElementById('ttsModeSystem');
const ttsVoiceSelect = document.getElementById('ttsVoice');
const ttsSupportIndicator = document.getElementById('ttsSupportIndicator');
const autoPlayTTS = document.getElementById('autoPlayTTS');
const vtuberToggle = document.getElementById('vtuberToggle');
const configMode = document.getElementById('configMode');
const vtuberMode = document.getElementById('vtuberMode');
const vtuberStatus = document.getElementById('vtuberStatus');
const characterGif = document.getElementById('characterGif');
const vtuberChatBubble = document.getElementById('vtuberChatBubble');
const vtuberInput = document.getElementById('vtuberInput');
const vtuberSendBtn = document.getElementById('vtuberSendBtn');
const toggleHistoryBtn = document.getElementById('toggleHistoryBtn');

// 状态变量
let conversationHistory = [];
let isGenerating = false;
let abortController = null;
let isConnected = false;
let speechSynthesis = window.speechSynthesis;
let currentSpeech = null;
let availableVoices = [];
let currentAudio = null;
let savedConfigs = {};
let currentTtsMode = 'custom'; // 'custom' 或 'system'
let isHistoryCollapsed = true; // 默认折叠历史记录
let currentVtuberState = 'idle';
let isVtuberMode = false;

// 文件路径常量
const SYSTEM_PROMPT_FILE = 'system_prompt.txt';

// 皮套状态
const VTUBER_STATES = {
    IDLE: 'idle',
    THINKING: 'thinking',
    SPEAKING: 'speaking',
    ERROR: 'error',
    USER_INPUT: 'user_input',
    HAPPY: 'happy',
    ANGRY: 'angry',
    SHY: 'shy',
    REQUEST: 'request'
};

// 状态文本
const STATUS_TEXTS = {
    idle: '待机中',
    thinking: '思考中...',
    speaking: '说话中',
    error: '出错了',
    user_input: '等待输入',
    happy: '开心',
    angry: '生气',
    shy: '害羞',
    request: '请求'
};

// GIF资源路径配置
const GIFS = {
    idle: ['./图片/待机-0.gif', './图片/待机-1.gif'],
    thinking: ['./图片/思考-0.jpg'],
    speaking: ['./图片/请求-0.gif', './图片/请求-1.gif', './图片/请求-2.gif'],
    error: ['./图片/故障-0.gif', './图片/故障-1.gif', './图片/故障-2.gif', './图片/故障-3.gif', './图片/故障-4.gif'],
    user_input: ['./图片/夜空.jpg', './图片/等待.gif'],
    happy: ['./图片/高兴-0.gif', './图片/高兴-1.gif', './图片/高兴-2.gif', './图片/高兴-3.gif'],
    angry: ['./图片/愤怒-0.gif', './图片/愤怒-1.gif'],
    shy: ['./图片/害羞-0.gif'],
    request: ['./图片/请求-0.gif', './图片/请求-1.gif', './图片/请求-2.gif']
};

// 修复后的配置应用函数
async function applyConfigToUI(config) {
    // 优先使用配置中的系统提示词
    if (config.systemPrompt) {
        systemPrompt.value = config.systemPrompt;
        displayedSystemPrompt.textContent = config.systemPrompt;
    } else {
        // 直接使用默认提示词，不再尝试加载文件
        const defaultPrompt = document.getElementById('embeddedSystemPrompt').value.trim();
        systemPrompt.value = defaultPrompt;
        displayedSystemPrompt.textContent = defaultPrompt;
    }

    // 应用其他配置
    apiEndpoint.value = config.endpoint || "http://localhost:1234";
    aiModel.value = config.model || "qwen/qwen3-30b-a3b";
    includeHistory.checked = config.includeHistory !== false;
    temperature.value = config.temperature || 0.7;
    maxTokens.value = config.maxTokens || 1024;
    ttsApiEndpoint.value = config.ttsApiEndpoint || "http://127.0.0.1:7860/tts";
    ttsSpeed.value = config.ttsSpeed || 1.0;
    ttsVolume.value = config.ttsVolume || 1.0;
    ttsSpeedValue.textContent = `${ttsSpeed.value}x`;
    ttsVolumeValue.textContent = `${Math.round(ttsVolume.value * 100)}%`;
    autoPlayTTS.checked = config.autoPlayTTS !== false;

    currentModel.textContent = aiModel.value;

    // 应用TTS模式
    if (config.ttsMode === 'system') {
        switchTtsMode('system');
    } else {
        switchTtsMode('custom');
    }
}

// 切换皮套模式
async function toggleVtuberMode() {
    // 如果是切换到皮套模式，则自动测试连接
    if (!isVtuberMode) {
        vtuberToggle.disabled = true;
        vtuberToggle.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 连接中...';

        try {
            // 执行测试连接
            const isConnected = await testConnection();

            if (!isConnected) {
                showApiStatus('无法连接到API，请检查配置！', 'error');
                vtuberToggle.disabled = false;
                vtuberToggle.innerHTML = '<i class="fas fa-user-astronaut"></i><span>皮套模式</span>';
                return;
            }
        } catch (error) {
            console.error("连接测试失败:", error);
            vtuberToggle.disabled = false;
            vtuberToggle.innerHTML = '<i class="fas fa-user-astronaut"></i><span>皮套模式</span>';
            return;
        }
    }

    isVtuberMode = !isVtuberMode;

    if (isVtuberMode) {
        configMode.style.display = 'none';
        vtuberMode.style.display = 'flex';
        vtuberToggle.classList.add('active');
        vtuberToggle.innerHTML = '<i class="fas fa-cog"></i><span>配置模式</span>';
        setVtuberState(VTUBER_STATES.IDLE);

        // 清空皮套模式聊天记录（但保留全局历史）
        vtuberChatBubble.innerHTML = "你好，我是月华！今天有什么可以帮你的吗？";
    } else {
        configMode.style.display = 'flex';
        vtuberMode.style.display = 'none';
        vtuberToggle.classList.remove('active');
        vtuberToggle.innerHTML = '<i class="fas fa-user-astronaut"></i><span>皮套模式</span>';
    }

    vtuberToggle.disabled = false;
}

// 设置皮套状态
function setVtuberState(state) {
    currentVtuberState = state;

    // 获取该状态对应的GIF数组
    const gifArray = GIFS[state];
    if (gifArray && gifArray.length > 0) {
        // 随机选择一个GIF
        const randomIndex = Math.floor(Math.random() * gifArray.length);
        characterGif.src = gifArray[randomIndex];
    } else {
        // 如果没有定义该状态的GIF，使用默认的思考状态GIF
        characterGif.src = 'gifs/thinking/thinking1.gif';
    }

    // 更新状态指示器
    vtuberStatus.innerHTML = `
        <div class="vtuber-status-dot"></div>
        <span>${STATUS_TEXTS[state]}</span>
    `;

    // 更新状态类
    vtuberStatus.className = 'vtuber-status';
    vtuberStatus.classList.add(`status-${state}`);
}

function handleEmotionTags(content) {
    // 定义情绪标签映射
    const emotionMap = {
        '<happy>': VTUBER_STATES.HAPPY,
        '<angry>': VTUBER_STATES.ANGRY,
        '<shy>': VTUBER_STATES.SHY,
        '<request>': VTUBER_STATES.REQUEST
    };

    let detectedEmotion = null;

    // 检查内容中是否包含情绪标签
    for (const [tag, emotion] of Object.entries(emotionMap)) {
        if (content.includes(tag)) {
            detectedEmotion = emotion;
            break;
        }
    }

    return detectedEmotion;
}

// 添加消息到聊天气泡
function addVtuberMessage(message, isUser = false) {
    // 如果有新消息，自动展开历史记录
    if (isHistoryCollapsed) {
        isHistoryCollapsed = false;
        document.querySelector('.chat-history-panel').classList.remove('collapsed');
    }

    const messageClass = isUser ? 'vtuber-user-message' : 'vtuber-ai-message';
    const messageElement = document.createElement('div');
    messageElement.className = `vtuber-message ${messageClass}`;

    // 使用Markdown解析内容
    const processedContent = processThinkTags(message);
    messageElement.innerHTML = processedContent;

    document.getElementById('vtuberChatBubble').appendChild(messageElement);

    // 高亮代码块
    messageElement.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });

    // 滚动到底部
    const chatBubble = document.getElementById('vtuberChatBubble');
    chatBubble.scrollTop = chatBubble.scrollHeight;
}

// 皮套模式发送消息
async function sendVtuberMessage() {
    const message = vtuberInput.value.trim();
    if (!message || isGenerating) return;

    // 添加用户消息
    const userMsgObj = {
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
    };
    conversationHistory.push(userMsgObj);
    addVtuberMessage(message, true);

    // 设置用户输入状态
    setStateWithTimeout(VTUBER_STATES.USER_INPUT, 1000);
    vtuberInput.value = '';

    // 设置思考状态（无超时）
    setVtuberState(VTUBER_STATES.THINKING);
    isGenerating = true;
    vtuberSendBtn.disabled = true;

    try {
        // 构建消息数组
        let messages = [];
        if (systemPrompt.value.trim() !== "") {
            messages.push({ role: 'system', content: systemPrompt.value });
        }
        conversationHistory.forEach(msg => {
            messages.push({ role: msg.role, content: msg.content });
        });

        // 创建AI消息元素
        const aiMessageElement = document.createElement('div');
        aiMessageElement.className = 'message ai-message';
        vtuberChatBubble.appendChild(aiMessageElement);
        const contentElement = document.createElement('div');
        contentElement.className = 'markdown-content';
        aiMessageElement.appendChild(contentElement);

        // 流式接收响应
        let assistantMessage = "";
        await fetchAIStreamResponse(messages, (chunk) => {
            assistantMessage += chunk;
            contentElement.innerHTML = processThinkTags(assistantMessage);
            // 高亮代码块
            contentElement.querySelectorAll('pre code').forEach((block) => {
                hljs.highlightElement(block);
            });

            // 绑定折叠事件
            bindThinkToggleEvents(contentElement);

            // 滚动到底部
            vtuberChatBubble.scrollTop = vtuberChatBubble.scrollHeight;
        });

        // 添加到历史记录
        const assistantMsgObj = {
            role: 'assistant',
            content: assistantMessage,
            timestamp: new Date().toISOString()
        };
        conversationHistory.push(assistantMsgObj);

        // 检测情绪标签
        const emotion = handleEmotionTags(assistantMessage);

        // 准备TTS内容（过滤括号和标签）
        const ttsContent = extractConclusion(assistantMessage);
        const cleanTtsContent = cleanTextForTTS(ttsContent);

        // 设置说话状态
        setVtuberState(VTUBER_STATES.SPEAKING);

        if (autoPlayTTS.checked && cleanTtsContent) {
            await playTTS(cleanTtsContent);
        }

        // 处理情绪标签
        if (emotion) {
            setStateWithTimeout(emotion);
        } else {
            setStateWithTimeout(VTUBER_STATES.IDLE);
        }
    }
    catch (error) {
        console.error("请求失败:", error);
        addVtuberMessage(`抱歉，出错了: ${error.message}`);
        // 错误状态优先级最高，覆盖其他状态
        setStateWithTimeout(VTUBER_STATES.ERROR, 2000);
    }
    finally {
        isGenerating = false;
        vtuberSendBtn.disabled = false;
    }
}

// 流式获取AI响应
async function fetchAIStreamResponse(messages, onChunkReceived) {
    const endpoint = apiEndpoint.value + '/v1/chat/completions';
    const model = aiModel.value;
    const temp = parseFloat(temperature.value);
    const maxToks = parseInt(maxTokens.value);

    try {
        // 构建请求体
        const requestBody = {
            model: model,
            messages: messages,
            temperature: isNaN(temp) ? 0.7 : temp,
            max_tokens: isNaN(maxToks) ? 1024 : maxToks,
            stream: true
        };

        // 发送请求
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            throw new Error(`API返回错误: ${response.status} ${response.statusText}`);
        }

        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let assistantMessage = "";

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter(line => line.trim() !== '');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.replace('data: ', '');
                    if (data === '[DONE]') {
                        return;
                    }

                    try {
                        const jsonData = JSON.parse(data);
                        if (jsonData.choices && jsonData.choices[0].delta && jsonData.choices[0].delta.content) {
                            onChunkReceived(jsonData.choices[0].delta.content);
                        }
                    } catch (e) {
                        console.error("解析流数据出错:", e);
                    }
                }
            }
        }
    } catch (error) {
        throw error;
    }
}

// 提取结论部分
function extractConclusion(content) {
    // 尝试匹配 <think> 标签
    const thinkMatch = content.match(/<think>([\s\S]*?)<\/think>([\s\S]*)/);
    if (thinkMatch) {
        return thinkMatch[2].trim();
    }

    // 尝试匹配思考区块的HTML结构
    const conclusionMatch = content.match(/<div class="conclusion">([\s\S]*?)<\/div>/i);
    if (conclusionMatch) {
        // 移除HTML标签，只保留文本内容
        return conclusionMatch[1].replace(/<[^>]*>/g, '').trim();
    }

    // 如果没有找到特定格式，返回整个内容
    return content;
}

// 处理<think>标签
function processThinkTags(content) {
    // 使用正则表达式匹配<think>标签
    const thinkRegex = /<think>([\s\S]*?)<\/think>([\s\S]*)/;
    const match = content.match(thinkRegex);

    let processedContent = '';

    if (match) {
        const thinkContent = match[1];
        const conclusion = match[2];

        // 使用Markdown渲染推理内容
        const renderedThink = marked.parse(thinkContent);
        const renderedConclusion = marked.parse(conclusion);

        processedContent = `
            <div class="think-block">
                <div class="think-header">
                    <span><i class="fas fa-lightbulb think-icon"></i> 推理过程</span>
                    <button class="toggle-think">折叠</button>
                </div>
                <div class="think-content">
                    ${renderedThink}
                </div>
            </div>
            <div class="conclusion">
                ${renderedConclusion}
            </div>
        `;
    } else {
        // 如果没有<think>标签，直接渲染整个内容
        processedContent = marked.parse(content);
    }
    // 确保mermaid图表被正确包装
    processedContent = processedContent.replace(
        /```mermaid([\s\S]*?)```/g,
        '<div class="mermaid">$1</div>'
    );
    return processedContent;
}

// 新增：清理文本用于TTS（移除括号和尖括号内容）
function cleanTextForTTS(text) {
    if (!text) return '';
    // 移除括号内的内容
    let cleanedText = text.replace(/\([^)]*\)/g, '');
    // 移除尖括号标签及其内容
    cleanedText = cleanedText.replace(/<[^>]+>/g, '');
    // 移除Markdown代码块
    cleanedText = cleanedText.replace(/```[\s\S]*?```/g, '');
    // 移除Markdown图像
    cleanedText = cleanedText.replace(/!\[.*?\]\(.*?\)/g, '');
    // 清理多余空格
    return cleanedText.replace(/\s{2,}/g, ' ').trim();
}

// 新增：带超时的状态设置函数
function setStateWithTimeout(state, duration = 9000) {
    setVtuberState(state);
    if (state !== VTUBER_STATES.IDLE && state !== VTUBER_STATES.THINKING) {
        setTimeout(() => {
            // 仅在仍是当前状态时切换回待机
            if (currentVtuberState === state) {
                setVtuberState(VTUBER_STATES.IDLE);
            }
        }, duration);
    }
}

// 绑定折叠按钮事件
function bindThinkToggleEvents(container) {
    container.querySelectorAll('.toggle-think').forEach(button => {
        button.addEventListener('click', function () {
            const thinkContent = this.closest('.think-block').querySelector('.think-content');
            thinkContent.classList.toggle('collapsed');

            if (thinkContent.classList.contains('collapsed')) {
                this.textContent = '展开';
            } else {
                this.textContent = '折叠';
            }
        });
    });
}

// 配置Marked解析器
marked.setOptions({
    highlight: function (code, lang) {
        const language = hljs.getLanguage(lang) ? lang : 'plaintext';
        return hljs.highlight(code, { language }).value;
    },
    langPrefix: 'hljs language-'
});

// 设置当前日期
function setCurrentDate() {
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    document.getElementById('currentDate').textContent = formattedDate;
}

// 主题切换功能
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    themeToggle.innerHTML = isDarkMode ?
        '<i class="fas fa-sun"></i>' :
        '<i class="fas fa-moon"></i>';
}

// 应用保存的主题
function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
}

// 获取当前配置
function getCurrentConfig() {
    return {
        endpoint: apiEndpoint.value,
        model: aiModel.value,
        systemPrompt: systemPrompt.value,
        includeHistory: includeHistory.checked,
        temperature: parseFloat(temperature.value),
        maxTokens: parseInt(maxTokens.value),
        ttsApiEndpoint: ttsApiEndpoint.value,
        ttsSpeed: parseFloat(ttsSpeed.value),
        ttsVolume: parseFloat(ttsVolume.value),
        ttsMode: currentTtsMode,
        autoPlayTTS: autoPlayTTS.checked
    };
}

// 保存配置到本地存储
function saveConfigToStorage(name) {
    const config = getCurrentConfig();
    savedConfigs[name] = config;
    localStorage.setItem('savedConfigs', JSON.stringify(savedConfigs));
    localStorage.setItem('currentConfig', name); // 保存当前配置名
    showApiStatus(`配置 "${name}" 已保存！`, 'success');
    renderConfigList();
}

// 加载配置
function loadConfig(name) {
    if (savedConfigs[name]) {
        applyConfigToUI(savedConfigs[name]);
        showApiStatus(`配置 "${name}" 已加载`, 'success');
    }
}

// 删除配置
function deleteConfig(name) {
    if (confirm(`确定要删除配置 "${name}" 吗？`)) {
        delete savedConfigs[name];
        localStorage.setItem('savedConfigs', JSON.stringify(savedConfigs));
        renderConfigList();
        showApiStatus(`配置 "${name}" 已删除`, 'success');
    }
}

// 删除所有配置
function deleteAllConfigs() {
    if (Object.keys(savedConfigs).length === 0) {
        showApiStatus('没有可删除的配置', 'warning');
        return;
    }

    if (confirm('确定要删除所有配置吗？此操作不可撤销！')) {
        savedConfigs = {};
        localStorage.removeItem('savedConfigs');
        renderConfigList();
        showApiStatus('所有配置已删除', 'success');
    }
}

// 渲染配置列表
function renderConfigList() {
    configList.innerHTML = '';

    if (Object.keys(savedConfigs).length === 0) {
        configList.innerHTML = '<p class="no-configs">没有保存的配置</p>';
        return;
    }

    for (const name in savedConfigs) {
        const configItem = document.createElement('div');
        configItem.className = 'config-item';
        configItem.innerHTML = `
            <div class="config-name">${name}</div>
            <div class="config-actions">
                <button class="config-btn load-btn" data-name="${name}">加载</button>
                <button class="config-btn delete-btn" data-name="${name}">删除</button>
            </div>
        `;
        configList.appendChild(configItem);
    }

    // 添加事件监听
    document.querySelectorAll('.load-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            loadConfig(this.dataset.name);
        });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            deleteConfig(this.dataset.name);
        });
    });
}

// 加载保存的配置
function loadSavedConfigs() {
    const saved = localStorage.getItem('savedConfigs');
    if (saved) {
        try {
            savedConfigs = JSON.parse(saved);
            renderConfigList();
        } catch (e) {
            console.error("Error parsing saved configs:", e);
            savedConfigs = {};
        }
    }
}

// 更新连接状态
function updateConnectionStatus(connected) {
    isConnected = connected;
    if (connected) {
        statusIndicator.className = "status-indicator status-connected";
        connectionStatusText.textContent = "已连接";
        sendButton.disabled = false;
        showApiStatus('API连接成功！', 'success');
    } else {
        statusIndicator.className = "status-indicator status-disconnected";
        connectionStatusText.textContent = "未连接";
        sendButton.disabled = false;
    }
}

// 测试连接并获取模型
async function testConnection() {
    const endpoint = apiEndpoint.value + '/v1/models';

    try {
        statusIndicator.className = "status-indicator status-warning";
        connectionStatusText.textContent = "连接中...";

        const response = await fetch(endpoint, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) throw new Error(`API返回错误: ${response.status}`);

        const data = await response.json();
        updateConnectionStatus(true);
        showApiStatus('连接成功！API服务正常。', 'success');
        updateModelDropdown(data.data || []);
        return true;
    } catch (error) {
        console.error("连接测试失败:", error);
        updateConnectionStatus(false);
        showApiStatus(`连接失败: ${error.message}`, 'error');
        return false;
    }
}

// 更新模型下拉框
function updateModelDropdown(models) {
    // 清空当前选项
    aiModel.innerHTML = '';

    // 添加新选项
    models.forEach(model => {
        const option = document.createElement('option');
        option.value = model.id;
        option.textContent = model.id;
        aiModel.appendChild(option);
    });

    // 如果之前有选中的模型，尝试选中它
    const currentConfig = getCurrentConfig();
    if (currentConfig.model) {
        const optionToSelect = Array.from(aiModel.options).find(option => option.value === currentConfig.model);
        if (optionToSelect) {
            optionToSelect.selected = true;
            currentModel.textContent = currentConfig.model;
        }
    }

    // 如果没有选中任何模型，选择第一个
    if (!aiModel.value && models.length > 0) {
        aiModel.value = models[0].id;
        currentModel.textContent = models[0].id;
    }

    showApiStatus(`已加载 ${models.length} 个可用模型`, 'success');
}

// 显示API状态消息
function showApiStatus(message, type) {
    apiStatus.textContent = message;
    apiStatus.className = `api-status api-${type}`;
    apiStatus.style.display = 'block';

    // 5秒后隐藏消息
    setTimeout(() => {
        apiStatus.style.display = 'none';
    }, 5000);
}

// 添加消息到历史
function addMessageToHistory(role, content) {
    const message = {
        role,
        content,
        timestamp: new Date().toISOString()
    };

    conversationHistory.push(message);
    return message;
}

// 渲染消息到聊天界面
function renderMessage(message) {
    const messageDiv = document.createElement('div');

    // 系统消息处理
    if (message.role === 'system') {
        messageDiv.classList.add('message', 'system-message');
        messageDiv.innerHTML = `
            <div class="message-header">
                <span>系统提示</span>
            </div>
            <div>${message.content}</div>
        `;
        chatHistory.appendChild(messageDiv);
        return messageDiv;
    }

    // 用户和AI消息处理
    const now = new Date(message.timestamp);
    const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    // 特殊处理：将Mermaid代码块转换为可渲染格式
    let processedContent = message.content;

    // 1. 预处理Mermaid代码块
    processedContent = processedContent.replace(
        /```mermaid([\s\S]*?)```/g,
        (match, diagram) => `<div class="mermaid">${diagram}</div>`
    );

    // 2. 处理其他代码块（保持原样）
    processedContent = processedContent.replace(
        /```([\s\S]*?)```/g,
        (match, code) => `<pre><code>${code}</code></pre>`
    );

    // 3. 处理表格（增强表格样式）
    processedContent = processedContent.replace(
        /<table>/g,
        '<table class="markdown-table">'
    );

    // 4. 使用Marked.js解析Markdown
    processedContent = marked.parse(processedContent);

    // 5. 添加响应式容器
    processedContent = processedContent.replace(
        /<div class="mermaid">/g,
        '<div class="mermaid-container"><div class="mermaid">'
    ).replace(
        /<\/div><\/div>/g,
        '</div></div>'
    );

    // 创建消息元素
    messageDiv.classList.add('message');
    messageDiv.innerHTML = `
        <div class="message-header">
            <span>${message.role === 'user' ? '用户' : 'Chat-AI'}</span>
            <span>${timestamp}</span>
        </div>
        <div class="markdown-content">${processedContent}</div>
        <div class="message-actions">
            <button class="action-btn" title="复制">
                <i class="fas fa-copy"></i>
            </button>
            ${message.role === 'assistant' ? `
            <button class="action-btn tts-btn" title="播放语音" data-content="${encodeURIComponent(message.content)}">
                <i class="fas fa-volume-up"></i>
            </button>
            ` : ''}
        </div>
    `;

    // 添加消息类型样式
    if (message.role === 'user') {
        messageDiv.classList.add('user-message');
    } else {
        messageDiv.classList.add('assistant-message');
    }

    // 添加到聊天历史
    chatHistory.appendChild(messageDiv);

    // 添加复制功能
    const copyBtn = messageDiv.querySelector('.action-btn');
    copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(message.content)
            .then(() => {
                const originalIcon = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => {
                    copyBtn.innerHTML = originalIcon;
                }, 2000);
            });
    });

    // 添加TTS功能
    if (message.role === 'assistant') {
        const ttsBtn = messageDiv.querySelector('.tts-btn');
        ttsBtn.addEventListener('click', function () {
            const content = decodeURIComponent(this.getAttribute('data-content'));
            playTTS(content);
        });
    }

    // 高亮代码块
    messageDiv.querySelectorAll('pre code').forEach((block) => {
        // 跳过Mermaid图表
        if (!block.closest('.mermaid-container')) {
            hljs.highlightElement(block);
        }
    });

    // 渲染Mermaid图表
    setTimeout(() => {
        const mermaidContainers = messageDiv.querySelectorAll('.mermaid');
        if (mermaidContainers.length > 0 && window.mermaid) {
            try {
                mermaid.init({
                    theme: document.body.classList.contains('dark-mode') ?
                        'dark' : 'default',
                    startOnLoad: true,
                    securityLevel: 'loose'
                }, mermaidContainers);
            } catch (e) {
                console.error('Mermaid渲染错误:', e);
                mermaidContainers.forEach(container => {
                    container.innerHTML = `<div class="mermaid-error">图表渲染失败: ${e.message}</div>`;
                });
            }
        }
    }, 100);

    setTimeout(() => {
        // 渲染数学公式
        renderMathInElement(contentElement, {
            delimiters: [
                { left: '$$', right: '$$', display: true },
                { left: '$', right: '$', display: false }
            ],
            throwOnError: false
        });
    }, 100);
    // 为think区块添加折叠功能
    messageDiv.querySelectorAll('.toggle-think').forEach(button => {
        button.addEventListener('click', function () {
            const thinkContent = this.closest('.think-block').querySelector('.think-content');
            thinkContent.classList.toggle('collapsed');

            if (thinkContent.classList.contains('collapsed')) {
                this.textContent = '展开';
            } else {
                this.textContent = '折叠';
            }
        });
    });

    // 添加表格样式增强
    const tables = messageDiv.querySelectorAll('table');
    tables.forEach(table => {
        if (!table.classList.contains('markdown-table')) {
            table.classList.add('markdown-table');
        }

        // 添加表头样式
        const headers = table.querySelectorAll('th');
        headers.forEach(header => {
            header.classList.add('table-header');
        });

        // 添加斑马纹
        const rows = table.querySelectorAll('tr');
        rows.forEach((row, index) => {
            if (index % 2 === 1) {
                row.classList.add('table-row-odd');
            }
        });
    });

    // 滚动到底部
    chatHistory.scrollTop = chatHistory.scrollHeight;

    return messageDiv;
}

// 发送消息到API
async function sendMessageToAPI(userMessage, useHistory) {
    if (!isConnected) {
        showApiStatus('未连接到API，请先测试连接！', 'error');
        return;
    }

    isGenerating = true;
    sendButton.disabled = true;

    // 创建中止控制器以便取消请求
    abortController = new AbortController();

    try {
        const endpoint = apiEndpoint.value + '/v1/chat/completions';
        const model = aiModel.value;
        const temp = parseFloat(temperature.value);
        const maxToks = parseInt(maxTokens.value);

        // 构建消息数组
        let messages = [];

        // 添加系统提示词（如果有）
        if (systemPrompt.value.trim() !== "") {
            messages.push({
                role: 'system',
                content: systemPrompt.value
            });
        }

        if (useHistory) {
            // 包含完整历史
            messages = messages.concat(conversationHistory.map(msg => ({
                role: msg.role,
                content: msg.content
            })));
        } else {
            // 只包含最后一条用户消息
            messages.push({
                role: 'user',
                content: userMessage.content
            });
        }

        // 构建请求体
        const requestBody = {
            model: model,
            messages: messages,
            temperature: isNaN(temp) ? 0.7 : temp,
            max_tokens: isNaN(maxToks) ? 1024 : maxToks,
            stream: true
        };

        // 发送请求
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody),
            signal: abortController.signal
        });

        if (!response.ok) {
            throw new Error(`API返回错误: ${response.status} ${response.statusText}`);
        }

        // 添加AI消息占位符
        const assistantMsgObj = addMessageToHistory('assistant', '');
        const messageElement = renderMessage(assistantMsgObj);
        const contentElement = messageElement.querySelector('.markdown-content');

        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let assistantMessage = "";

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n').filter(line => line.trim() !== '');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.replace('data: ', '');
                    if (data === '[DONE]') {
                        break;
                    }

                    try {
                        const jsonData = JSON.parse(data);
                        if (jsonData.choices && jsonData.choices[0].delta && jsonData.choices[0].delta.content) {
                            assistantMessage += jsonData.choices[0].delta.content;

                            // 更新消息内容
                            assistantMsgObj.content = assistantMessage;

                            // 使用统一的处理函数
                            contentElement.innerHTML = processThinkTags(assistantMessage);

                            // 高亮代码块
                            contentElement.querySelectorAll('pre code').forEach((block) => {
                                hljs.highlightElement(block);
                            });

                            // 为think区块添加折叠功能
                            contentElement.querySelectorAll('.toggle-think').forEach(button => {
                                button.addEventListener('click', function () {
                                    const thinkContent = this.closest('.think-block').querySelector('.think-content');
                                    thinkContent.classList.toggle('collapsed');

                                    if (thinkContent.classList.contains('collapsed')) {
                                        this.textContent = '展开';
                                    } else {
                                        this.textContent = '折叠';
                                    }
                                });
                            });

                            // 自动滚动
                            chatHistory.scrollTop = chatHistory.scrollHeight;
                        }
                    } catch (e) {
                        console.error("解析流数据出错:", e);
                    }
                }
            }
        }

        showApiStatus('消息发送成功！', 'success');

        // 如果启用了自动播放功能，播放语音
        if (autoPlayTTS.checked) {
            // 延迟500ms确保消息完全渲染
            setTimeout(() => { playTTS(); }, 500);
        }
    }
    catch (error) {
        if (error.name === 'AbortError') {
            showApiStatus('请求已取消', 'error');
        } else {
            console.error("API调用失败:", error);
            showApiStatus(`错误: ${error.message}`, 'error');

            // 添加错误消息到聊天记录
            const errorMsg = `抱歉，请求处理时出错: ${error.message}`;
            const errorMsgObj = addMessageToHistory('assistant', errorMsg);
            renderMessage(errorMsgObj);
        }
    }
    finally {
        isGenerating = false;
        sendButton.disabled = false;
        abortController = null;
    }
}

// 发送消息
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    // 添加用户消息
    const userMsgObj = addMessageToHistory('user', message);
    renderMessage(userMsgObj);
    userInput.value = '';

    // 发送到API
    await sendMessageToAPI(userMsgObj, includeHistory.checked);
}

// 清除系统提示词
function clearSystemPrompt() {
    systemPrompt.value = '';
    displayedSystemPrompt.textContent = "未设置系统提示词";
    showApiStatus('系统提示词已清除', 'success');
}

// 切换TTS模式
function switchTtsMode(mode) {
    currentTtsMode = mode;

    if (mode === 'system') {
        ttsModeSystem.classList.add('active');
        ttsModeCustom.classList.remove('active');
        systemTtsPanel.style.display = 'block';
        customTtsPanel.style.display = 'none';
    } else {
        ttsModeCustom.classList.add('active');
        ttsModeSystem.classList.remove('active');
        systemTtsPanel.style.display = 'none';
        customTtsPanel.style.display = 'block';
    }
}

// 加载系统TTS语音
function loadSystemTtsVoices() {
    // 检查浏览器是否支持语音合成
    if (!('speechSynthesis' in window)) {
        ttsSupportIndicator.className = 'tts-support-indicator tts-not-supported';
        ttsSupportIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> 浏览器不支持系统TTS功能';
        return;
    }

    // 获取可用的语音
    availableVoices = speechSynthesis.getVoices();

    // 清空语音选择框
    ttsVoiceSelect.innerHTML = '';

    // 添加语音选项
    availableVoices.forEach(voice => {
        const option = document.createElement('option');
        option.value = voice.name;
        option.textContent = `${voice.name} (${voice.lang})`;
        ttsVoiceSelect.appendChild(option);
    });

    // 尝试选择中文语音（如果可用）
    const chineseVoice = availableVoices.find(voice =>
        voice.lang.startsWith('zh') || voice.lang.startsWith('cmn')
    );

    if (chineseVoice) {
        ttsVoiceSelect.value = chineseVoice.name;
    }
}

// 播放TTS
async function playTTS(text) {
    // 获取需要朗读的文本
    let textToPlay = text;

    // 如果未提供文本，尝试获取最后一条AI消息
    if (!textToPlay) {
        const lastAssistantMsg = [...conversationHistory]
            .reverse()
            .find(msg => msg.role === 'assistant');

        if (lastAssistantMsg) {
            textToPlay = lastAssistantMsg.content;
        }
    }

    // 提取结论部分
    let finalText = extractConclusion(textToPlay);

    // 如果没有提取到结论，使用整个文本
    if (!finalText) {
        finalText = textToPlay;
    }

    // 清理文本（移除括号和尖括号内容）
    const cleanedText = cleanTextForTTS(finalText);

    if (!cleanedText) {
        if (!isVtuberMode) {
            showApiStatus('没有可用的AI消息用于TTS', 'error');
        }
        return;
    }

    // 截断过长的文本
    const truncatedText = cleanedText.length > 2000 ?
        cleanedText.substring(0, 2000) + '...' : cleanedText;

    try {
        // 停止当前正在播放的语音
        stopTTS();

        // 更新状态
        if (isVtuberMode) {
            setVtuberState(VTUBER_STATES.SPEAKING);
        } else {
            ttsButton.disabled = true;
            ttsButton.innerHTML = currentTtsMode === 'custom' ?
                '<i class="fas fa-spinner fa-spin"></i> 生成中...' :
                '<i class="fas fa-volume-up"></i> 播放中...';
        }

        if (currentTtsMode === 'custom') {
            await playCustomTTS(truncatedText);
        } else {
            playSystemTTS(truncatedText);
        }

        if (!isVtuberMode) {
            showApiStatus('语音生成中...', 'success');
        }
    } catch (error) {
        console.error("TTS播放失败:", error);

        if (!isVtuberMode) {
            showApiStatus(`TTS错误: ${error.message}`, 'error');
            ttsButton.disabled = false;
            ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放';
        } else {
            setVtuberState(VTUBER_STATES.IDLE);
        }
    }
}

// 使用自定义TTS API播放
async function playCustomTTS(text) {
    const endpoint = ttsApiEndpoint.value;
    const speed = parseFloat(ttsSpeed.value);

    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            text: text,
            speed: speed
        })
    });

    if (!response.ok) {
        throw new Error(`TTS API错误: ${response.status} ${response.statusText}`);
    }

    // 获取音频数据
    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);

    // 创建音频元素
    currentAudio = new Audio(audioUrl);
    currentAudio.volume = parseFloat(ttsVolume.value);
    currentAudio.play();

    // 更新按钮状态
    if (!isVtuberMode) {
        ttsButton.disabled = false;
        ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放中...';
    }

    // 音频播放结束事件
    currentAudio.onended = function () {
        if (isVtuberMode) {
            setVtuberState(VTUBER_STATES.IDLE);
        } else {
            ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放';
        }
        URL.revokeObjectURL(audioUrl);
    };
}

// 使用系统TTS播放
function playSystemTTS(text) {
    // 停止任何正在进行的语音
    speechSynthesis.cancel();

    // 创建新的语音实例
    const utterance = new SpeechSynthesisUtterance(text);

    // 设置语音参数
    utterance.rate = parseFloat(ttsSpeed.value);
    utterance.volume = parseFloat(ttsVolume.value);

    // 设置语音（如果可用）
    const selectedVoice = availableVoices.find(voice => voice.name === ttsVoiceSelect.value);
    if (selectedVoice) {
        utterance.voice = selectedVoice;
    }

    // 播放语音
    speechSynthesis.speak(utterance);

    // 更新状态
    utterance.onend = function () {
        if (isVtuberMode) {
            setVtuberState(VTUBER_STATES.IDLE);
        } else {
            ttsButton.disabled = false;
            ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放';
        }
    };

    currentSpeech = utterance;
}

// 停止语音播放
function stopTTS() {
    // 停止自定义TTS
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
        if (isVtuberMode) {
            setVtuberState(VTUBER_STATES.IDLE);
        } else {
            ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放';
        }
    }

    // 停止系统TTS
    if (speechSynthesis) {
        speechSynthesis.cancel();
    }

    if (!isVtuberMode) {
        ttsButton.disabled = false;
        ttsButton.innerHTML = '<i class="fas fa-play"></i> 播放';
    }
}

// 切换历史记录面板
function toggleHistoryPanel() {
    const historyPanel = document.querySelector('.chat-history-panel');
    isHistoryCollapsed = !isHistoryCollapsed;
    historyPanel.classList.toggle('collapsed', isHistoryCollapsed);
}

// 事件监听
vtuberToggle.addEventListener('click', toggleVtuberMode);
vtuberSendBtn.addEventListener('click', sendVtuberMessage);
vtuberInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendVtuberMessage();
    }
});
themeToggle.addEventListener('click', toggleTheme);
saveConfigBtn.addEventListener('click', () => {
    const config = getCurrentConfig();
    configJson.value = JSON.stringify(config, null, 2);
    configName.value = '';
    saveModal.style.display = 'flex';
    configName.focus();
});
testConnectionBtn.addEventListener('click', testConnection);
sendButton.addEventListener('click', sendMessage);
clearSystemPromptBtn.addEventListener('click', clearSystemPrompt);
ttsButton.addEventListener('click', () => playTTS(ttsText.value.trim()));
stopTTSBtn.addEventListener('click', stopTTS);
ttsSpeed.addEventListener('input', function () {
    ttsSpeedValue.textContent = `${this.value}x`;
});
ttsVolume.addEventListener('input', function () {
    ttsVolumeValue.textContent = `${Math.round(this.value * 100)}%`;
});
importConfigBtn.addEventListener('click', () => {
    importModal.style.display = 'flex';
    importConfigJson.value = '';
    importConfigJson.focus();
});
deleteAllConfigsBtn.addEventListener('click', deleteAllConfigs);
ttsModeCustom.addEventListener('click', () => switchTtsMode('custom'));
ttsModeSystem.addEventListener('click', () => switchTtsMode('system'));
confirmSaveBtn.addEventListener('click', () => {
    const name = configName.value.trim();
    if (!name) {
        alert('请输入配置名称');
        return;
    }
    saveConfigToStorage(name);
    saveModal.style.display = 'none';
});
cancelSaveBtn.addEventListener('click', () => saveModal.style.display = 'none');
confirmImportBtn.addEventListener('click', () => {
    try {
        const config = JSON.parse(importConfigJson.value);
        applyConfigToUI(config);
        importModal.style.display = 'none';
        showApiStatus('配置导入成功！', 'success');
    } catch (e) {
        showApiStatus('无效的配置JSON', 'error');
    }
});
cancelImportBtn.addEventListener('click', () => importModal.style.display = 'none');
document.querySelectorAll('.close-modal').forEach(btn => {
    btn.addEventListener('click', () => {
        saveModal.style.display = 'none';
        importModal.style.display = 'none';
    });
});
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});
aiModel.addEventListener('change', function () {
    currentModel.textContent = this.value;
});
toggleHistoryBtn.addEventListener('click', toggleHistoryPanel);

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
    applySavedTheme();
    setCurrentDate();
    updateConnectionStatus(false);
    loadSavedConfigs();
    mermaid.initialize(
        {
            startOnLoad: true,
            theme: document.body.classList.contains('dark-mode') ? 'dark' : 'default',
            securityLevel: 'loose',
            fontFamily: 'inherit'
        }
    );
    // 为初始模板消息绑定折叠事件
    const initialMessage = document.querySelector('.assistant-message .markdown-content');
    if (initialMessage) {
        bindThinkToggleEvents(initialMessage);
    }
    // 应用当前配置（如果有）
    const currentConfigName = localStorage.getItem('currentConfig');
    if (currentConfigName && savedConfigs[currentConfigName]) {
        await applyConfigToUI(savedConfigs[currentConfigName]);
    } else {
        // 应用默认配置
        await applyConfigToUI({});
    }

    // 确保输入框可用
    userInput.disabled = false;
    sendButton.disabled = false;

    // 加载系统TTS语音
    if ('speechSynthesis' in window) {
        speechSynthesis.onvoiceschanged = loadSystemTtsVoices;
        loadSystemTtsVoices();
    } else {
        ttsSupportIndicator.className = 'tts-support-indicator tts-not-supported';
        ttsSupportIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> 浏览器不支持系统TTS功能';
        if (currentTtsMode === 'system') switchTtsMode('custom');
    }

    // 设置皮套模式初始状态
    setVtuberState(VTUBER_STATES.IDLE);
});