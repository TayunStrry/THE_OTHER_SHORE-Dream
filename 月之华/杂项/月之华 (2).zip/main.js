// 主入口文件
// 初始化并协调各模块

import ConfigManager from './configManager.js';
import ApiService from './apiService.js';
import MessageRenderer from './messageRenderer.js';
import TtsService from './ttsService.js';
import VtuberManager from './vtuberManager.js';
import EventHandlers from './eventHandlers.js';

// 初始化所有模块
function initialize() {
  ConfigManager.loadSavedConfigs();
  TtsService.loadSystemTtsVoices();
  EventHandlers.bindMessageEvents();
  EventHandlers.bindConfigEvents();
  EventHandlers.bindTtsEvents();
  EventHandlers.bindVtuberEvents();
  EventHandlers.bindThemeEvents();
}

// 启动应用
document.addEventListener('DOMContentLoaded', initialize);