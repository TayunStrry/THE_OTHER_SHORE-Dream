/**
 * 系统初始化事件
 */
async function systemInitializationEvent() {
	// 应用保存的主题
	applySavedTheme();
	// 设置当前日期
	setCurrentDate();
	// 更新连接状态
	updateConnectionStatus(false);
	// 加载保存的配置
	loadSavedConfigs();
	// 初始化 Mermaid 配置
	mermaid.initialize(
		{
			startOnLoad: true,
			theme: document.body.classList.contains("dark-mode") ? "dark" : "default",
			securityLevel: "loose",
			fontFamily: "inherit",
		}
	);
	/**
	 * 获取初始模板消息
	 */
	const initialMessage = document.querySelector(".assistant-message .markdown-content");
	// 如果存在初始模板消息，则绑定折叠事件
	if (initialMessage) bindThinkToggleEvents(initialMessage);
	// 应用当前配置（如果有）
	const currentConfigName = localStorage.getItem("currentConfig");
	// 如果有保存的配置，则应用该配置
	if (currentConfigName && savedConfigs[currentConfigName]) await applyConfigToUI(savedConfigs[currentConfigName]);
	// 否则应用默认配置
	else await applyConfigToUI({});
	// 加载系统 TTS 语音
	if ("speechSynthesis" in window) {
		// 绑定语音加载事件，但不立即加载
		speechSynthesis.onvoiceschanged = () => {
			loadSystemSpeechModelVoiceSelect();
			// 解绑事件避免重复加载
			speechSynthesis.onvoiceschanged = null;
		};
		// 首次加载语音
		loadSystemSpeechModelVoiceSelect();
	}
	else {
		// 如果浏览器不支持系统 TTS 功能，显示提示信息
		ttsSupportIndicator.className = "tts-support-indicator tts-not-supported";
		ttsSupportIndicator.innerHTML = '<i class="fas fa-exclamation-triangle"></i> 浏览器不支持系统 TTS 功能';
		// 如果当前语音引擎是系统模式，切换到自定义模式
		if (currentSpeechEngineType === "system") switchSpeechEngineMode("custom");
	}
	// 设置角色模式初始状态
	setVtuberState(VTUBER_STATES.IDLE);
};
// TODO: 绑定 系统初始化事件
document.addEventListener("DOMContentLoaded", systemInitializationEvent);
// TODO: 绑定 语音模型音量滑块事件
speechModelVolumeSlider.addEventListener("input", () => speechModelVolumeValue.textContent = `${Math.round(speechModelVolumeSlider.value * 100)}%`);
// TODO: 绑定 语音模型语速滑块事件
speechModelSpeedSlider.addEventListener("input", () => speechModelSpeedValue.textContent = `${speechModelSpeedSlider.value}x`);
// TODO: 绑定 推理模型类型显示切换事件
reasoningModelDropdown.addEventListener("change", () => currentModel.textContent = reasoningModelDropdown.value);